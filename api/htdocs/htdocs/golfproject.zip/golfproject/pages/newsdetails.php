                	<h1>News and Events</h1>
                    
                    <!-- events starts -->
                    <div id="events">
                    	
 
                        <ul>
        <?php                    
    $news_id= $_GET['news_id'];
    $sql= "select * from news where 1=1 and news_id='$news_id'";
    $objdatabase->query=$sql;
    $objdatabase->execute();
    while ($row=$objdatabase-> fetch_array()){
    ?>

                        	<li>
                            	<span class="eDate"><?php echo $row['news_date'] ?></span><br />
                                <span class="eTitle"><?php echo $row['news_title'] ?></span><br />
                               
                                <?php echo $row['news_description'];?> <br />
                            </li>
                            
    <?php } ?>
                        </ul>
                    
                    </div>

