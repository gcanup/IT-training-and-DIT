<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Golf Community</title>
<link href="control/style.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 7]>
<script defer type="text/javascript" src="js/pngfix.js"></script>
<![endif]-->
</head>

<body>
<!-- wrapper starts -->


	<!-- main starts -->

    

 
        
 
        
        <!-- container starts -->
       
        	
            <!-- containerL starts -->
           
            
            	
                
                <div class="clContent">
                
                	<h1>Members registration:</h1>
                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ut sollicitudin faucibus massa. Sed ante. Aenean lorem nisl, hendrerit tempor, commodo vel, varius et, velit. Quisque eros tortor, viverra vitae, feugiat nec, imperdiet vitae, justo. Integer gravida velit vitae elit. Curabitur egestas. Sed id leo. Cras at lectus. Ut dignissim. Quisque quis libero vel sem vulputate nonummy. Vivamus orci lectus, rutrum vitae, venenatis sit amet, dapibus sit amet, justo. Aenean vitae erat. Ut quis leo. Morbi sodales condimentum nibh.</p>
                
                	<!-- signup starts -->
                    <div id="signup">
                    
                    	<form action="" method="get">
                        	
                            <div class="suMain">
                            	<div class="suColL">First Name:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Last Name:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">E-mail ID:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /><br /><span class="suLightTxt">A confirmation will be sent to this email address</span></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Location:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">User Name:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Password:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Confirm Password:</div>
                                <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">&nbsp;</div>
                                <div class="suColR"><input name="" type="image" src="images/but-submit.gif" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                        </form>
                    
                    </div>
                	<!-- signup ends -->
                
                </div><!-- end of class clContent -->
            
            
            <!-- containerL ends -->
            
            <!-- containerR starts -->
            
            <!-- containerR ends -->
            
            
        
            
        <!-- container ends -->
        
        <!-- footer starts -->
        
    
    
	<!-- main ends -->


<!-- wrapper ends -->
</body>
</html>
