                	<h1>News and Events</h1>
                    
                    <!-- events starts -->
                    <div id="events">
                    	
 
                        <ul>
        <?php                    
    $sno = 1;   // explanation one more time, $sno ? if want to make next custom
    $sql= "select * from news where 1=1";
    $objdatabase->query=$sql;
    $objdatabase->execute();
    while ($row=$objdatabase-> fetch_array()){
    ?>

                        	<li>
                            	<span class="eDate"><?php echo $row['news_date'] ?></span><br />
                                <span class="eTitle"><?php echo $row['news_title'] ?></span><br />
                                <span id="toggle"> <?php echo substr($row['news_description'],0,200) ?> </span><br />
                               
                               
                                
                                <a href="index.php?p=newsdetails&news_id=<?php echo $row['news_id']?>" title="Read More....">Read More....</a>
                            </li>
                            
    <?php } ?>
                        </ul>
                    
                    </div>