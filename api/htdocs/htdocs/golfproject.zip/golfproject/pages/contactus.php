<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Feedback</title>
<link href="control/style.css" rel="stylesheet" type="text/css" />
<!--[if lt IE 7]>
<script defer type="text/javascript" src="js/pngfix.js"></script>
<![endif]-->
</head>

<body>
<?php

$objdatabase->table='tbl_feedback';
session_start();
$msg='';
        if($_SERVER['REQUEST_METHOD']=='POST'){
            
//           print_r($_SESSION);
//           exit();
           
            $name=$_POST['name'];
            $date=$_POST['date'];
            $email=$_POST['email'];
            $address=$_POST['address'];
            $country=$_POST['country'];
            $subject=$_POST['subject'];
            $message=$_POST['message'];
            $captcha_key=$_POST['captcha_key'];
            $isFormValid=true;
            
            if ($name==""){
                $isFormValid=false;
                $msg.='Name is empty'. ('<br />');
                
            }
            if ($captcha_key==""){
                $isFormValid=false;
                $msg.='Please enter security key'. ('<br />');
                
            }
           if ($captcha_key!=$_SESSION['security_code']){
               $isFormValid=false;
                $msg.='Invalid security key'. ('<br />');
           }
            echo $msg. ('<br />');
            
            
            if ($isFormValid==true){
                $objdatabase->data=array("date"=>$date,
                    "name"=>$name, "email"=>$email, "address"=>$address, "country"=>$country, "subject"=>$subject, "message"=>$message,);
            
                $success=$objdatabase->insert();
                if($success==true){
                    echo 'data inserted successfully';
                    
                    //For Mail open
                $email_to = "gclncguy@gmail.com, angc@utu.fi";
                $email_subject = "Message From online form to Anup Gc";
                $email_message = " Hello Anup,
                You have this email received from your website contact form.
                Please try responding back as soon as possible on the following inquries.
                Form details:\n\n";
                function clean_string($string) {
                $bad = array("content-type","bcc:","to:","cc:","href");
                return str_replace($bad,"",$string);
                }
                $email_message .= "Name: ".clean_string($name)."\n";
                $email_message .= "Email: ".clean_string($email)."\n";
                $email_message .= "Subject : ".clean_string($subject)."\n";
                $email_message .= "Message: ".clean_string($message)."\n\n";
                // create email headers
                $headers = 'From: '.$email_from."\r\n".
                'Reply-To: '.$email_from."\r\n" .
                'X-Mailer: PHP/' . phpversion();
                @mail($email_to, $email_subject, $email_message, $headers);
                echo '<script>
                alert("Thank You, We will Response you as Soon as Possible");
                </script>';
                //For Mail Close
                } else {
                    
                    $msg.= "Error while inserting";
                }
            }
                        
        }
?>

    

 
        
 
        
        <!-- container starts -->
       
        	
            <!-- containerL starts -->
           
            
            <h1> Feedback Form: </h1>  	
                
                <div class="clContent">
                
                
                
                	<!-- signup starts -->
                    <div id="signup">
                    
                        <form action="" method="post" id="feedbackform">
                        	
                            <div class="suMain">
                            	<div class="suColL">Date:</div>
                                <div class="suColR"><input name="date" type="date" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Name:</div>
                                <div class="suColR"><input name="name" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">E-mail ID:</div>
                                <div class="suColR"><input name="email" type="email" class="suInpTxt" /><br /><span class="suLightTxt">A confirmation will be sent to this email address</span></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            
                                <div class="suMain">
                            	<div class="suColL"> Address:</div>
                                <div class="suColR"><input name="address" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            
                            <div class="suMain">
                            	<div class="suColL">Country:</div>
                               <div class="suColR">
                                    <?php echo generateCountrySelect($_POST['country'])  ?> 
                               </div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            

                            
                            <div class="suMain">
                            	<div class="suColL">Subject:</div>
                                <div class="suColR"><input name="subject" type="text" class="suInpTxt" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">Message</div>
                                <div class="suColR">
                                    <textarea name="message" rows="4" cols="50"> </textarea></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL"></div>
                                <div class="suColR">
                                   <img src=" <?php echo SITE_FRONT_URL?>includes/CaptchaSecurityImages.php?height=30&width=150&characters=5"/>
                                </div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                          <div class="suMain">
                            	<div class="suColL">Enter Security Key</div>
                                <div class="suColR"><input name="captcha_key" type="text" class="suInpTxt"  /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                            <div class="suMain">
                            	<div class="suColL">&nbsp;</div>
                                <div class="suColR"><input name="" type="image" src="images/but-submit.gif" /></div>
                                <div class="clearfloat"></div>
                            </div><!-- end of class suMain -->
                            
                        </form>
                    
                    </div>
                	<!-- signup ends -->
                
                </div><!-- end of class clContent -->
            
            
            <!-- containerL ends -->
            
            <!-- containerR starts -->
            
            <!-- containerR ends -->
            
            
        
            
        <!-- container ends -->
        
        <!-- footer starts -->
        
    
    
	<!-- main ends -->


<!-- wrapper ends -->
</body>
</html>
