<?php

error_reporting(E_ALL & ~E_NOTICE);
session_start();
include_once ('includes/database.php');
$objdatabaselogin= new database();                     // why new obj for class ? 
$page=isset($_GET['page'])?$_GET['page']:'home';
$msg='';

if ($_SERVER['REQUEST_METHOD']== "POST") {
    $ad_user = $_POST['user'];
    $ad_pass = $_POST['pass'];
    $isFormValid = true;


    if ($ad_user=="") {
        $isFormValid=false;
        echo '<script> alert("Username is required") </script>';
    }
    if ($ad_pass=="") {
        $isFormValid=false;
        echo '<script> alert("Password is required") </script>';
    }
    $ad_pass=md5($ad_pass);
    if ($isFormValid==true) {
//        echo $ad_user."<br>";
//        echo $ad_pass;
//        exit;
        $sql="select * from admin_user where username='$ad_user' && password='$ad_pass'";
        $objdatabaselogin->query=$sql;                                                      
        $result= $objdatabaselogin->execute();                  
        $total_rows= mysqli_num_rows($result);
        $row=mysqli_fetch_assoc($result);
        if ($total_rows >0) {
            $_SESSION['id']=$row['user_id'];
            $_SESSION['username']=$row['username'];
            $_SESSION['password']=$row['password'];
            $_SESSION['email']=$row['email'];
            header('location:index.php');
        }else {$msg.="Username of Password is incorrect";

        }
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin login page</title>
    <link href="css/template.css" rel="stylesheet" type="text/css"/>
</head>
<body class="body">

<br>
<br>


<div class="container">
    <div class="header" >
        <?php include_once('pageparts/header.php')?>
    </div>
    
    <div class="content">
    <fieldset>
        <legend><strong>Admin login</strong></legend>
        <form action="" method="POST" name="admin_login" id="admin_login">
            <table width="60%" border="0">
                <tr>
                    <td colspan="2">
                        <div class="err_msg">
                            <?php
                            echo $msg;
                            ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>Username</td>
                    <td><input type="text" value="" name="user" id="user" size="30" maxlength="100"><span class="red">*</span></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" value="" name="pass" id="pass" size="30" maxlength="100"><span class="red">*</span></td>
                </tr>

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" name="submit" id="submit" value="Login">
                        <input type="reset" name="reset" id="reset" value="Clear">
                    </td>
                </tr>


            </table>
        </form>

    </fieldset>
    </div>
</div>     <!-- container closed -->
<div class="footer">
    <?php include_once('pageparts/footer.php') ?>
</div>




</body>
</html>


