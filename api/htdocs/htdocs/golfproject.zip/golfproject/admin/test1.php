<?php

if(isset($_POST['nameValue'])){
    echo $_POST['nameValue'];
}
?>