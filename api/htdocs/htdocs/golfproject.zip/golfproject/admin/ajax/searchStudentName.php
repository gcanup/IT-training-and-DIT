<?php

error_reporting(E_ALL & ~E_NOTICE);
include_once ('../includes/functions.php');
$objdatabase1 = new Functions();
if(isset($_POST['nameValue'])){
 //echo $_Post['nameValue'];
    $searchValue=$_POST['nameValue'];
    $sqlSelect= "select * from student where name like '%$searchValue%' order by std_id";
    $objdatabase1->query=$sqlSelect;
    $objdatabase1->execute();
    $strDisplay='<ul style="list-style-type:none;padding:0;margin:0">';
    
    while ($row=$objdatabase1->fetch_array()){
        $strDisplay.='<li>'.$row["name"]. '</li>';
    }
    $strDisplay.='</ul>';
    echo $strDisplay;
    exit;
}
if(isset($_POST['nameValue1'])){
 //echo $_Post['nameValue'];
    $searchValue=$_POST['nameValue1'];
    $sqlSelect= "select * from student where address like '%$searchValue%' order by std_id";
    $objdatabase1->query=$sqlSelect;
    $objdatabase1->execute();
    $strDisplay='<ul style="list-style-type:none;padding:0;margin:0">';
    
    while ($row=$objdatabase1->fetch_array()){
        $strDisplay.='<li>'.$row["address"]. '</li>';
    }
    $strDisplay.='</ul>';
    echo $strDisplay;
    exit;
}

?>