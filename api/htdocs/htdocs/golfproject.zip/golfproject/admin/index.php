<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();
if ($_SESSION['id']=='') {
    header('location:login.php');    ////redirect to login page when session is empty
}
include_once ('includes/config.php');
$objdatabase = new Functions();              //// why to call constructor
$page=isset($_GET['page'])!=""?$_GET['page']:'home';

?>

<html>
<head>
    <link type="text/css" rel="stylesheet" href="css/template.css" />
    <!---calendar   -->
             <link rel="stylesheet" type="text/css" href="<?php echo SITE_URL?>calender/JSCal2/css/jscal2.css" />
         <link rel="stylesheet" type="text/css" href="<?php echo SITE_URL?>calender/JSCal2/css/border-radius.css" />
         <link rel="stylesheet" type="text/css" href="<?php echo SITE_URL?>calender/JSCal2/css/steel/steel.css" />
        <script type="text/javascript" src="<?php echo SITE_URL?>calender/JSCal2/js/jscal2.js"></script>
        <script type="text/javascript" src="<?php echo SITE_URL?>calender/JSCal2/js/lang/en.js"></script>
        <script src="js/jquery.js" type="text/javascript"></script>
        <!--Ckeditor -->
     <script type="text/javascript" src="<?php echo SITE_URL?>ckeditor/ckeditor.js"></script>

</head>

<body class="body" onload="">


<div class="header" >
    <div class="container">
    <?php include_once("pageparts/header.php")?>
</div>
</div>
    <div class="container">
<div class="menu" >
    <?php include_once("pageparts/menu.php")?>
</div>
<div class="content">

    <?php include_once("page/$page.php") ?>
</div>

<div class="footer">
    <?php include_once("pageparts/footer.php")?>

</div>

</div>
</body>



</html>


