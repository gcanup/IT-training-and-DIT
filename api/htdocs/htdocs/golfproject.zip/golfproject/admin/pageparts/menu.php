    <ul>
        <li> <a href="index.php"> Home </a> </li>
        <li> <a href="index.php?page=student">Student</a></li>
        <li> <a href="index.php?page=cms">Content</a></li>
        <li> <a href="index.php?page=news">News</a></li> 
        <li> <a href="index.php?page=gallery">Gallery</a></li> 
        <li> <a href="index.php?page=user">Admins</a></li>
        <li> <a href="index.php?page=listFeedback">Feedback </a></li>
        <li> <a href="logout.php">Logout</a></li>
        <div class="clear"> </div>
    </ul>
