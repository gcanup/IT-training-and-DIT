


        <div class="logo">
            <img src="images/logo.jpg" alt="logo" /> </div>
        <div class="top-mid">
            <h2> Simple Template </h2>
        </div>

        <div class="top-right"> </div>
        <div class="clear"> </div>


