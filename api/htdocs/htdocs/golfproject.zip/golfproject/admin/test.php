<html>
    <head>
        <title>Jquery test</title>
        <script language="javascript" src="js/jquery.js" type="text/javascript"> </script>
        <script src="js/ajax.js" type="text/javascript"></script>
        <script language="javascript">

            $(document).ready(function(){
                
              
          // alert('Page Load Successfully')
            
          //  $('.banner').css('background','yellow');   //if want to add extra css feature ?
      
          
    });
            </script>
    </head>
    <body>
       <!-- <div class="banner"> Hello world </div>   -->
       
       <div>
           <form>
               <input type="text" id="name">
               <input type="button" id="button" value="send">
               <div class="ditmsg"> </div>
           </form>
       </div>
       
    </body>
</html>