<?php


//$sql= "select * from admin_user";



    if (isset($_GET['mode'])=="D"){
    $ad_id=$_GET['ad_id'];
    $objdatabase->table='admin_user';
    $objdatabase->cond=array('user_id'=>$ad_id);
    if ($objdatabase->delete()){  
        
    echo 'Deteted successfully';
    echo '<script language="JavaScript">
        window.location="index.php?page=user" ;</script>';
    }
    else{
    echo 'Error while deleting';
    }

  
    }
?>

<h2> Search Admins </h2>
<form action="" name="search"method="post">
    <table width="80%" align="center" border="1" cellspacing="0" cellpadding="5"  >
                <tr>
                <td align="right">
                    Name:
                </td>
                <td>
                    <input type="text" value="<?php echo $_POST['fname'] ?>" name="fname"/>            <!--  this post value id  -->
                </td>
                <td align="right">
                    Username:
                </td>
                <td>
                    <input type="text" value="<?php echo $_POST['username'] ?>" name="uname"/>
                </td>
            </tr>
            <tr>
                <td align="right" >
                    Email:
                </td>
                <td colspan="3">
                    <input type="text" value="<?php echo $_POST['email'] ?>" name="email"/>
                </td>
            </tr>
            <tr>
                <td colspan="4" align="center">
                    <input type="submit" name="submit" id="submit" value="Search"/>&nbsp;&nbsp;&nbsp;
                    <input type="reset" name="reset" id="reset" value="Clear" onclick="window.location = 'index.php?page=user'"/>
                </td>
            </tr>
    
    </table>
</form>    




<h2 align="center">Admin User Data</h2>
<table width="60%" cellspacing="0" cellpadding="15" border="1" align="center">
    <tr>
    <td colspan="8" align="right">
        <a href="index.php?page=addUser&mode=I">Add new Admin</a></td>
    </tr>
    <tr colspan="6">
        <th>S.No</th>
        <th>Full name</th>
        <th>Username</th>
        <th>Password</th>
        <th>Email</th>
        <th>Status</th>
        <th colspan="2">Action</th>
    </tr>

    <?php
    
    if ($_POST['fname']!= "") {
        $name = $_POST['fname'];
        $sql.=" and fullname like '%$name%'";
    }
    if ($_POST['uname']!= "") {
        $username = $_POST['uname'];
        $sql.=" and username like '%$username%'";
    }
    if ($_POST['email']!= "") {
        $email = $_POST['email'];
        $sql.=" and email = '$email'";
    }
 //   $sno=1;
    
    $sno = isset($_GET['np']) ? $_GET['np'] == 1 ? 1 : $_GET['np'] * 5 - 4 : 1;
    $sql= "select * from admin_user where 1=1";

    $paginate=$objdatabase->listAdminUser($sql);
//    echo "<pre>";
//    print_r($paginate);
//    exit();
    $objdatabase->query=$paginate[1];
    $result= $objdatabase->execute(); 
    while ($row=mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?php echo $sno++ ?></td>
            <td><?php echo $row['fullname'] ?></td>
            <td><?php echo $row['username'] ?></td>
            <td><?php echo $row['password'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><?php echo $row['status'] ?></td>
            <td><a href="index.php?page=addUser&mode=U&ad_id=<?php echo $row['user_id'] ?>">EDIT</a></td>
            <td><a onclick="return confirm('Do you really want to delete?')"
                   href="index.php?page=user&mode=D&ad_id=<?php echo $row['user_id'] ?>">DELETE</a></td>



        </tr>
    <?php
    }


    ?>
                <tr>
            <td colspan="8" align="center">
                <?php echo $paginate[2]?>
            </td>
        </tr>
</table>


