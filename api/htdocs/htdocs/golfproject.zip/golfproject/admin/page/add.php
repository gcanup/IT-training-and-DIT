<?php
$objdatabase->table='student';   


// do we need to write connections here

$msg='';
$mode=$_GET['mode'];
$std_id=isset($_GET['std_id'])?$_GET['std_id']:'';
if($mode=='U'){
    $sql = "select * from student where std_id='$std_id'";
    $objdatabase->query=$sql;   
    $result=$objdatabase->execute();
    $row = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD']=="POST"){
    $std_name=$_POST['std_name'];
    $std_age=$_POST['std_age'];
    $std_add=$_POST['std_add'];
    $std_dob=$_POST['std_dob'];
    $std_gen=$_POST['std_gen'];
    $mode=$_POST['mode'];
    $std_id=$_POST['std_id'];   
    $isFormValid=true;


    if ($std_name==""){
        $isFormValid=false;
        echo '<script>
        alert ("Name is empty")
        </script>';
    }
    if ($std_age==""){
        $isFormValid=false;
        $msg.='Age is empty.';
        echo " $msg <br />";
    }
    if ($std_gen==""){
        $isFormValid=false;
        $msg.='Gender is empty.';
        echo $msg;
    }
    if ($isFormValid==true) {
        $objdatabase->data=array("name"=>$std_name,
                                "age"=>$std_age,
                                "address"=>$std_add,
                                "dob"=>$std_dob,
                                "gender"=>$std_gen,);
                            if ($mode=="I") {
                                $success=$objdatabase->insert();    //$success is ? can we remove that name ?
                            }else {
                                $objdatabase->cond=array('std_id'=>$std_id);   //we didnt write in mode U condition
                                $success= $objdatabase->update();
                            }
        if ($success==true) {
            echo 'student added successfully';
            echo '<script language="JavaScript">
                    window.location="index.php?page=student";
                    </script>';
        }
        else {
            $msg.='Error while Inserting';
        }

    }
}


?>

<html>
<head>
    <title>Add new student</title>
</head>
<body>
    <h2 align="center">Add new Student:</h2>
    <h3 align="center">Please fill the form below</h3>
    <form action="" name="std_new" id="std_new" method="post" onsubmit="returnvalidateForm(this)">
            <input type="hidden" name="std_id" value="<?php echo $row['std_id']?>" />
            <input type="hidden" name="mode" value="<?php echo $mode?>" />

        <table align="center" width="50%" border="0" cellspacing="5px" cellpadding="5px">
        <tr>
            <td colspan="2" align="right">
                <a href="index.php?page=student">Back to Table</a>
            </td>
        </tr>
            <tr>
                <td>Name: </td>
                <td><input type="text" value="<?php echo isset($row['name'])?$row['name']:"" ?>" name="std_name" id="std_name" size="40" maxlength="100"/></td>
            </tr>
            <tr>
                <td>Age: </td>
                <td><input type="number" value="<?php echo isset($row['age'])?$row['age']:"" ?>" name="std_age" id="std_age" size="40" ></td>
            </tr>
            <tr>
                <td>Address: </td>
                <td><input type="text" value="<?php echo isset($row['address'])?$row['address']:""?>" name="std_add" id="std_add" size="40" maxlength="100"/></td>
            </tr>
            <tr>
                <td>Date of Birth</td>
                <td><input type="date" value="<?php echo isset($row['dob'])?$row['dob']:"" ?>" name="std_dob" id="std_dob"/></td>

            </tr>
            <tr>
                <td>Gender: </td>
                <td><input type="radio"  name="std_gen" id="std_gen"
                           value="male"<?php echo isset($row['gender'])?$row['gender']=='male'?"checked='checked'":$row['gender']='female':$row['gender']='' ?>/> Male
                    <input type="radio" name="std_gen" id="std_gen"
                           value="female" <?php echo isset($row['gender'])?$row['gender']=='female'?"checked='checked'":$row['gender']='male':$row['gender']='' ?> />Female

                </td>
            </tr>
            <br>
            <tr>
                <td colspan="2" align="left">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<input type="submit" name="submit"  id="submit" value="Register"/>
               <input type="reset" id="reset" value="Clear"/></td>
            </tr>


        </table>




    </form>
</body>
</html>

