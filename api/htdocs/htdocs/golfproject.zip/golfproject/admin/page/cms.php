<?php
if($_GET['mode']=='D') {
    $cms_id=$_GET['cms_id'];
    $objdatabase->table='cms';
    $objdatabase->cond=array('cms_id'=>$cms_id);
    if($objdatabase->delete()) {
        echo '<script language="javascript">
            window.location=index.php?page=cms;
</script>';
    } else {
        echo 'error while deleting';
    }
    
}
?>
<fieldset >
    <legend>Search Contents</legend>
    <form name="searchContent" action="" method="post">
        <table width="90%"  align="center" border="1" cellspacing="0" cellpadding="5">
            <tr>
                <td align="right">
                    Content Title:
                </td>
                <td>
                    <input type="text" value="" name="title"/>            <!--  name is taken for search,  -->
                </td>
                <td align="right">
                    Date
                </td>
                <td>
                    <input type="date" value="" name="date"/>
                </td>
            </tr>

                <td colspan="4" align="center">
                    <input type="submit" name="submit" id="submit" value="Search"/>&nbsp;&nbsp;&nbsp;
                    <input type="reset" name="reset" id="reset" value="Clear" onclick="window.location = 'index.php?page=cms'"/>
                </td>
            </tr>
        </table>
    </form>
</fieldset>
<br/>

<h2> Contents </h2>

<table border="1" cellspacing="0" cellpadding="5" width="95%">
    <tr>
    <td colspan="8" align="right"><a href="index.php?page=addCms&mode=I">Add new Content </td>
    </tr>
    <tr>
        <th>Content ID </th>
        <th>Content Title</th>
        <th>Description</th>
        <th>Date</th>
        <th>Order</th>
        <th>Status</th>
        <th colspan="2">Action </th>
    </tr>

<?php


if($_POST['title']!==""){
    $title= $_POST['title'];
    $sql.= " and cms_title like '%$title%'";
}
if($_POST['date']!==""){
    $date= $_POST['date'];
    $sql.= " and cms_date like '%$date%'";
}

    $sno = isset($_GET['np']) ? $_GET['np'] == 1 ? 1 : $_GET['np'] * 5 - 4 : 1;   // explanation one more time
    $sql= "select * from cms";

    $paginate=$objdatabase->listContentPage($sql);
//    echo "<pre>";                     // questions in here
//    print_r($paginate);
$objdatabase->query=$paginate[1];
$objdatabase->execute();



while($row=$objdatabase->fetch_array()) {  //  sometimes $result inside the bracket
?>
    <tr> 
        <td><?php echo $sno++; ?></td>
        <td><?php echo $row['cms_title']; ?></td>
        <td><?php echo $row['cms_description']; ?></td>
        <td><?php echo $row['cms_date']; ?></td>
        <td><?php echo $row['cms_order']; ?></td>
        <td><?php if($row['cms_status']=='Y'){ echo 'Active';} else {echo 'Inactive';} ?></td>
        <td><a href="index.php?page=addCms&mode=U&cms_id=<?php echo $row['cms_id'] ?>">Edit </a></td>
        <td><a onclick="return confirm ('Do you reallyu want to delete?')" href="index.php?page=cms&mode=D&cms_id=<?php echo $row['cms_id']?>">Delete </a></td>
        
    </tr>
    
<?php
}
?>

                <tr>
            <td colspan="8" align="center">
                <?php echo $paginate[2]?>
            </td>
        </tr>

    
</table>
