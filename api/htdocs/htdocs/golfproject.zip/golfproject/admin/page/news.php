<?php
if (isset($_GET['mode'])== "D"){
    $news_id=$_GET['news_id'];
    $objdatabase->table='news';
    $objdatabase->cond=array('news_id'=>$news_id);    //'news_id'=$news_id =database and url
    if($objdatabase->delete()) {
               echo '<script language="javascript">
                window.location="index.php?page=news";
            </script>';
    }else{
      echo "error while deleting";  
    } 
    }


?>

<h2> Search News </h2>
<fieldset >
    <legend>Search News</legend>
    <form name="searchStudent" action="" method="post">
        <table width="90%"  align="center" border="1" cellspacing="0" cellpadding="5">
            <tr>
                <td align="right">
                    News Title:
                </td>
                <td>
                    <input type="text" value="" name="title"/>            <!--  name is taken for search,  -->
                </td>
                <td align="right">
                    News Reporter:
                </td>
                <td>
                    <input type="text" value="" name="reporter"/>
                </td>
            </tr>
            <tr>

                <td align="right">
                    News Date:
                </td>
                <td colspan="3">
                    <input type="text" value="" name="date"/>
                </td>
            </tr>
            <tr>
                <td colspan="4" align="center">
                    <input type="submit" name="submit" id="submit" value="Search"/>&nbsp;&nbsp;&nbsp;
                    <input type="reset" name="reset" id="reset" value="Clear" onclick="window.location = 'index.php?page=student'"/>
                </td>
            </tr>
        </table>
    </form>
</fieldset>
<br><br>
<h2> News </h2>
<table name="news" width="95%"  border="1" cellspacing="0" cellpading="5">
        <tr>
        <td colspan="8" align="right">
            <a href="index.php?page=addNews&mode=I">Add New News</a>
        </td>
    </tr>
    <tr>
        <th>S.No.</th>
        <th>News Title</th>
        <th>News Reporter</th>
        <th>News Description</th>
        <th>News Date</th>
        <th>Status</th>  
        <th colspan="2">Action</th>

    </tr>
    

<?php
$sql="select * from news where 1=1";
    if ($_POST['title'] != "") {
        $title = $_POST['title'];
        $sql.=" and news_title like '%$title%'";
    }
    if ($_POST['reporter'] != "") {
        $reporter = $_POST['reporter'];
        $sql.=" and news_reporter like '%$reporter%'";
    }
    if ($_POST['date'] != "") {
        $date = $_POST['date'];
        $sql.=" and news_date = '$date'";                 
    }

    $sno = isset($_GET['np']) ? $_GET['np'] == 1 ? 1 : $_GET['np'] * 5 - 4 : 1;   // explanation one more time, $sno ? if want to make next custom
    $sql= "select * from news where 1=1";

    $paginate=$objdatabase->listNewsPage($sql);
//    echo "<pre>";                     // questions in here
//    print_r($paginate);
$objdatabase->query=$paginate[1];
$objdatabase->execute();
while ($row=$objdatabase-> fetch_array()){
?>

    <tr><td> <?php echo $sno++ ?> </td> 
        <td><?php echo $row['news_title'] ?></td>
        <td><?php echo $row['news_reporter'] ?></td>
        <td><?php echo $row['news_description'] ?></td>
        <td><?php echo $row['news_date'] ?></td> 
        <td> <?php 
                $status= $row['status']=='Y'?'Active': 'Inactive';
                echo $status;
               ?> </td>
        <td><a href="index.php?page=addNews&mode=U&news_id=<?php echo $row['news_id'] ?>"> Edit </a></td>
        <td><a onclick="return confirm('Do you really want to delete ?')" href="index.php?page=news&mode=D&news_id=<?php echo $row['news_id']?> "> Delete </a></td>
    </tr>
    
    
<?php
}
?>
                <tr>
            <td colspan="8" align="center">
                <?php echo $paginate[2]?>
            </td>
        </tr>
</table>