<?php
$objdatabase->table='cms';
$msg='';
$mode=$_GET['mode'];
$cms_id =isset($_GET['cms_id'])? $_GET['cms_id'] : '';


if ($mode=="U") {
    $sql = "select * from cms where cms_id='$cms_id'";
    $objdatabase->query=$sql;
    $result= $objdatabase->execute();
    $row=mysqli_fetch_assoc($result);
}

if($_SERVER['REQUEST_METHOD']=="POST") {
    $cms_title= $_POST['cms_title'];
    $cms_desc=$_POST['cms_desc'];
    $cms_date=$_POST['cms_date'];
    $cms_order=$_POST['cms_order'];
    $status=$_POST['status'];
    $mode=$_POST['mode'];
    $cms_id=$_POST['cms_id'];
    $isFormValid= true;
    $success =false;
    
    if($cms_title=='') {
        $isFormValid=false;
        $msg.='Title is empty <br />';          
    }
        if($cms_date=='') {
        $isFormValid=false;
        $msg.='Date is missing';          
    }
   if($isFormValid==true) {
       $objdatabase->data=array('cms_title'=>$cms_title,
                'cms_description'=>$cms_desc,
                'cms_date'=>$cms_date,
                'cms_order'=>$cms_order,
                'cms_status'=>$status,);
   if($mode=="I") {
       $success=$objdatabase->insert();
   } else {
       $objdatabase->cond=array('cms_id'=>$cms_id);
       $success=$objdatabase->update();
         }
   if($success==true) {
       echo 'Content Added Successfully';
       echo '<script language="javascript">
       window.location="index.php?page=cms" ;
            </script>';
   }
   else {
       echo 'error while inserting';
   }
    
   }  
}

?>




<form method="post" action="">
    <input type="hidden" name="mode" id="mode" value="<?php echo $mode ?>" />
     <input type="hidden" name="cms_id" id="cms_id" value="<?php echo $cms_id ?>" />
    <table>
        <tr><td colspan="2" align="right"><a href="index.php?page=cms">Back to Content </a></td></tr>
    <tr colspan="2">
    <div class="err_msg">
    <?php echo $msg; ?>
    </div>
    </tr> 
    <tr>
        <td>Content Title </td>
        <td> <input type="text" value="<?php echo $row['cms_title'] ?>" name="cms_title" id="cms_title" size="40" /> </td> 
    </tr>
    <tr>
                <td>Content Description </td>
                <td> <textarea row="5" cols="50" value="" name="cms_desc" id="cms_decs" size="40" class="ckeditor" ><?php echo $row['cms_description'] ?></textarea> </td>         <!--row size -->
    </tr> 
    <tr>
                <td>Content Date </td>
        <td> <input type="date" value="<?php echo $row['cms_date'] ?>" name="cms_date" id="cms_date" size="40" />
                        <span>
                    <img src="calender/cal.gif" id="calendar-trigger"/>
                </span>
                <script>			
                    Calendar.setup({
                        trigger    : "calendar-trigger",
                        dateFormat: "%Y-%m-%d",
                        inputField : "cms_date",
                        min: 20060108,
                        max: 20681225,
                        onSelect   : function() { this.hide("slow") }
                    });
                </script></td>
    </tr> 
    <tr>
        <td>Content Order </td>
        <td> <input type="text" value="<?php echo $row['cms_order'] ?>" name="cms_order" id="cms_order" size="40" /> </td>
    </tr>
    <tr>
        <td>Status </td>
                <td> <input type="radio" name="status" id="status" value="Y" <?php if($row['cms_status']=="Y"){echo 'checked="checked"';} ?>/>Active
                    <input type="radio" name="status" id="status" value="N" <?php if($row['cms_status']=="N"){echo 'checked="checked"';} ?>/>Inactive
                </td>
        
    </tr> 
    <tr colspan="2">
    <td><input type="submit" name="submit" value="Submit" /> &nbsp;&nbsp;&nbsp;
        <input type="reset" name="reset" value="Clear" /> </td>
    </tr>
        
    </table>

</form>