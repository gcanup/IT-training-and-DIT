<?php
error_reporting(E_ALL & ~E_NOTICE);
if ($_SESSION['id']=='') {
    echo '<script language="javascript">
                window.location="../logout.php";
            </script>';   ////redirect to login page when session is empty
}
$objdatabase->table='admin_user';
$msg = "";
$mode = $_GET['mode'];
$ad_id=isset($_GET['ad_id'])?$_GET['ad_id']:'';
if($mode=='U'){
    $sql = "select * from admin_user where user_id='$ad_id'";
    $objdatabase->query=$sql;   
    $result=$objdatabase->execute();
    $row = mysqli_fetch_assoc($result);
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $username = $_POST['user'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $con_password = $_POST['con_password'];
    $status = $_POST['status'];
    $ad_id = $_POST['ad_id'];   
    $mode = $_POST['mode'];
    $isFormValid = true;

    if ($username == "") {
        $isFormValid = false;
        $msg.="User Name is Empty !!<br/>";
    }
    if ($fullname == "") {
        $isFormValid = false;
        $msg.="Full Name is Empty !!<br/>";
    }
    if ($password == "") {
        $isFormValid = false;
        $msg.="Password is Empty !!<br/>";
    }
    if ($con_password == "") {
        $isFormValid = false;
        $msg.="Confirm Password is Empty !!<br/>";
    }
    if ($password!=$con_password) {
        $isFormValid = false;
        $msg.="Password and Confirm Password Doesnot Match !!<br/>";
    }
    $password=md5($password);
    if ($isFormValid==true){    
        $objdatabase->data=array("username"=>$username,
                                "fullname"=>$fullname,
                                "password"=>$password,
                                "email"=>$email,
                                "status"=>$status,);
        
        if ($mode=='I') {
                                $success=$objdatabase->insert();    
                            }else {
                                $objdatabase->cond=array('user_id'=>$ad_id);   
                                $success= $objdatabase->update();
                            }                    

        if ($success==true) {
            ///header('location:index.php');
            echo '<script language="javascript">
                window.location="index.php?page=user";
            </script>';
        } else {
            $msg = "Error While Inserting";
        }
    }
}


//$en=base64_encode('Ram');
//echo "<br/>";
//echo md5('Ram');
//echo "<br/>";
//echo base64_decode($en);
?>
<fieldset>
    <legend><strong>User Registration</strong></legend>
    <form name="std_reg" id="std_reg" action="" method="post">
        <input type="hidden" name="ad_id" value="<?php echo $row['user_id'] ?>"/>
        <input type="hidden" name="mode" value="<?php echo $mode ?>"/>
        <table width="60%" border="0">
            <tr>
                <td colspan="2" align="right">
                    <a href="index.php?page=user">Back</a>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <div class="err_msg">
                        <?php
                        echo $msg;
                        ?>
                    </div>
                </td>
            </tr>
            <tr>
                <td colspan="2" align="right">
                    <span class="red">*</span> Fields Indicate Mandatory Field
                </td>
            </tr>
            <tr>
                <td>User Name</td>
                <td><input type="text" value="<?php echo isset($row['username'])?$row['username']:''?>" name="user" id="user" size="30" maxlength="20"/><span class="red">*</span></td>
            </tr>
            <tr>
                <td>Full Name</td>
                <td><input type="text" value="<?php echo isset($row['fullname'])?$row['fullname']:'' ?>" name="fullname" id="fullname" size="30" maxlength="100"/><span class="red">*</span></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" id="password" size="30" maxlength="100"/><span class="red">*</span></td>
            </tr>
            <tr>
                <td>Confirm Password</td>
                <td><input type="password" name="con_password" id="con_password" size="30" maxlength="100"/><span class="red">*</span></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="text" value="<?php echo isset($row['email'])?$row['email']:''?>" name="email" id="email" size="30" maxlength="200"/></td>
            </tr>
            <tr>
                <td>Status</td>
                <td>
                    <input type="radio" name="status" id="status" value="Y" <?php echo isset($row['status'])?$row['status']=='Y'?'checked="checked"':$row['status']='N':$row['status']=''?>/>Active
                    <input type="radio" name="status" id="status" value="N" <?php echo isset($row['status'])?$row['status']=='N'?'checked="checked"':$row['status']='Y':$row['status']=''?>/>In-Active
                </td>
            </tr>
            <tr>
                <td colspan="2" align="center">
                    <input type="submit" name="submit" id="submit" value="Save"/>&nbsp;&nbsp;&nbsp;
                    <input type="reset" name="reset" id="reset" value="Clear"/>
                </td>
            </tr>
        </table>
    </form>
</fieldset>
