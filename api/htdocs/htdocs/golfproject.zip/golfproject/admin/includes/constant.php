<?php

if($_SERVER['HTTP_HOST']=='localhost'){
	define('HOST','localhost');
	define('USERNAME','linkinfo_system');
	define('PASSWORD','manager');
	define('DATABASE_NAME','linkinfo_mydb_anup');
        define('SITE_URL','http://localhost/golfproject/admin'); // url of our site
        define('SITE_PATH',$_SERVER['DOCUMENT_ROOT']."/golfproject/admin"); // path of our site
	define('SITE_FRONT_URL','http://localhost/golfproject/'); // url of our admin panel
	define('SITE_FRONT_PATH',$_SERVER['DOCUMENT_ROOT']."/golfproject/"); //path of our admin panel
	define('GALLERY_PATH',$_SERVER['DOCUMENT_ROOT']."/golfproject/admin/gallery/"); //path of our gallery
	define('GALLERY_URL',SITE_URL."/gallery/"); //url of our gallery
}   
    
?>