            <a href="index.php" title="Home" class="navActive">Home</a>
            
                    <?php                    
 
    $sql= "select * from cms where 1=1 and cms_status='Y'";
    $objdatabase->query=$sql;
    $result=$objdatabase->execute();
    while ($row=$objdatabase-> fetch_array()){
    ?>
            <a href="index.php?p=cms&id=<?php echo $row['cms_id']; ?> " title="club rules"><?php echo $row['cms_title']; ?> </a>
            <?php }?>
            <a href="index.php?p=news" title="Club Rules">Club Rules</a>
            <a href="index.php?p=history" title="History">History</a>
            <a href="index.php?p=events" title="Famous Events">Famous Events</a>
            <a href="#" title="Famous Members">Famous Members</a>
            <a href="index.php?p=contactus" title="Contact">Contact</a>
        
            <div class="clearfloat"></div>