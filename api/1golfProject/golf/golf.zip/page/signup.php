
<h1>Members registration:</h1>
<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ut sollicitudin faucibus massa. Sed ante. Aenean lorem nisl, hendrerit tempor, commodo vel, varius et, velit. Quisque eros tortor, viverra vitae, feugiat nec, imperdiet vitae, justo. Integer gravida velit vitae elit. Curabitur egestas. Sed id leo. Cras at lectus. Ut dignissim. Quisque quis libero vel sem vulputate nonummy. Vivamus orci lectus, rutrum vitae, venenatis sit amet, dapibus sit amet, justo. Aenean vitae erat. Ut quis leo. Morbi sodales condimentum nibh.</p>

<!-- signup starts -->
<div id="signup">

    <form action="" method="get">

        <div class="suMain">
            <div class="suColL">First Name:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">Last Name:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">E-mail ID:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /><br /><span class="suLightTxt">A confirmation will be sent to this email address</span></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">Location:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">User Name:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">Password:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">Confirm Password:</div>
            <div class="suColR"><input name="" type="text" class="suInpTxt" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

        <div class="suMain">
            <div class="suColL">&nbsp;</div>
            <div class="suColR"><input name="" type="image" src="images/but-submit.gif" /></div>
            <div class="clearfloat"></div>
        </div><!-- end of class suMain -->

    </form>

</div>
<!-- signup ends -->