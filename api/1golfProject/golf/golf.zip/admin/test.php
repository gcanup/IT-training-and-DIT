<html>
    <head>
        <title>JQuery Demo DIT</title>
        <script language="javascript" src="js/jquery.js" type="text/javascript"></script>
        <script language="javascript" src="js/ajax.js" type="text/javascript"></script>
     </head>
    <body>  
        <div>
            <form>
                <label>Enter Your Name</label>
                <input type="text" id="name">
                <input type="button" id="button" value="Send">
                <div class="DITmsg"></div>
            </form>
        </div>
    </body>
</html>
