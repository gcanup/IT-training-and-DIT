<span class="footer-link">
    &COPY;DIT Solution
</span>