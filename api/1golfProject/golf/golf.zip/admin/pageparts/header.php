<div class="left_logo">
    <img src="images/header.jpg" height="100" width="100" style="margin: 10px;"/>
</div>
<div class="right_heading">
    <h1>Site Administration Panel</h1>
</div>