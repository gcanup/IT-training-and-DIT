<a href="index.php">Home</a>
<a href="index.php?page=listUser">Users</a>
<a href="index.php?page=listStudent">Students</a>
<a href="index.php?page=listcms">Content</a>
<a href="index.php?page=listNews">News</a>
<a href="index.php?page=listGallery">Gallery</a>
<a href="index.php?page=listFeedback">Feedback</a>
<a href="logout.php">Logout</a>
