<p>
    <a href="index.html" title="Home">Home</a> | 
    <a href="index.html" title="Club Rules">Club Rules</a> | 
    <a href="index.html" title="History">History</a> | 
    <a href="index.html" title="Famous Events">Famous Events</a> | 
    <a href="index.html" title="Famous Members">Famous Members</a> | 
    <a href="index.html" title="Contact">Contact</a>
</p>
<p>&copy; 2008 Callaway Golf Company. All Rights Reserved</p>